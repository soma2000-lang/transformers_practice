# Should be run from the same directory where `pipeline_flux_with_cfg_batched.py` is.

from diffusers import DiffusionPipeline
import torch 

pipeline = DiffusionPipeline.from_pretrained(
    "black-forest-labs/FLUX.1-dev", 
    torch_dtype=torch.bfloat16, 
    custom_pipeline="pipeline_flux_with_cfg_batched.py"
)
pipeline.enable_model_cpu_offload()
prompt = "a watercolor painting of a unicorn"
negative_prompt = "pink"

img = pipeline(
    prompt=prompt, 
    negative_prompt=negative_prompt, 
    true_cfg=1.5, 
    guidance_scale=3.5, 
    num_images_per_prompt=1,
    generator=torch.manual_seed(0)
).images[0]
img.save("cfg_flux_batched.png")